//
//  ViewController.swift
//  Test
//
//  Created by Arun Karra on 6/18/19.
//  Copyright © 2019 Amit Karra. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return statement.count
    }
    
    var statement=["groceries", "chores", "homework", "shopping"]
   
    
    @IBOutlet weak var TextBox: UITextField!
    @IBOutlet weak var Table: UITableView!
    
    
    func tablloueView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return statement.count
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if(editingStyle == UITableViewCell.EditingStyle.delete){
            statement.remove(at: indexPath.row)
            Table.reloadData()
            writeArrayToFile()
        }
    }
    
    let strFileName = "SMBdataBaseTest.txt"
    let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = UITableViewCell(style: .default, reuseIdentifier: "cellID")
        cell1.textLabel?.text = statement[indexPath.row]
        return cell1
    }
    
    override func viewDidAppear(_ animated: Bool) {
        Table.reloadData()
    }
    
    @IBAction func Button(_ sender: Any) {
        if (TextBox.text != "") {
            statement.append(TextBox.text! )
            writeArrayToFile()
            Table.reloadData()
            TextBox.text = ""
        }
    }
    override func viewDidLoad()
    {
        super.viewDidLoad()
        readDataFromFile()
        
    }
        
    func readDataFromFile() {
        let fileURL = dir?.appendingPathComponent(strFileName)
        
        let fileManager = FileManager.default
        let pathComponent = dir!.appendingPathComponent(strFileName)
        let filePath = pathComponent.path
        
        if fileManager.fileExists(atPath: filePath)
        {
            statement = NSMutableArray(contentsOf: fileURL!) as! [String]
        }
        else
        {
            writeArrayToFile()
        }
    
    }
    func writeArrayToFile()
    {
        let fileURL = (dir?.appendingPathComponent(strFileName))!
        (statement as NSArray).write(to: fileURL, atomically: true)
    }
        
   

    
}
    
    
    
    
    



    
    
    
    
    
    
    
    
   
    



